import gdafront from "../assets/gda-front.webp";

export { gdafront };
